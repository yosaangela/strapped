// from the documentation gulp

// Load all the modules from package.json
var gulp = require( 'gulp' ),
 plumber = require( 'gulp-plumber' ),
 autoprefixer = require('gulp-autoprefixer'),
  watch = require( 'gulp-watch' ),
  livereload = require( 'gulp-livereload' ),
  jshint = require( 'gulp-jshint' ),
  stylish = require( 'jshint-stylish' ),
  uglify = require( 'gulp-uglify' ),
  rename = require( 'gulp-rename' ),
  notify = require( 'gulp-notify' ),
  include = require( 'gulp-include' ),
  sass = require( 'gulp-sass' );
  imagemin = require('gulp-imagemin');
  bower = require('gulp-bower');
  zip = require('gulp-zip');

var config = {
     bowerDir: './bower_components' 
}
 
// Default error handler
var onError = function( err ) {
  console.log( 'An error occured:', err.message );
  this.emit('end');
}

// Zip files up
gulp.task('zip', function () {
 return gulp.src([
   '*',
   './fonts/*',
   './inc/*',
   './js/**/*',
   './languages/*',
   './sass/**/*',
   './template-parts/*',
   '!bower_components',
   '!node_modules',
  ], {base: "."})
  .pipe(zip('strapped.zip'))
  .pipe(gulp.dest('.'));
});

